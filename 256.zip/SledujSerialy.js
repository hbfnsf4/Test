(function () {
    'use strict';
    function FreePremium_initIframe(hrefElement) {
        let style = document.createElement("style");
        style.textContent = `
            #playerNotice {
                display: none !important;
            }
        `
        document.documentElement.appendChild(style);
        let PlayerNotice = document.querySelector("#playerNotice");
        if (PlayerNotice) {
            PlayerNotice.remove();
        }

        let overlay = document.createElement("div");
        overlay.textContent = "Fetching video URL...";

        overlay.style.position = "absolute";
        overlay.style.top = "0";
        overlay.style.left = "0";
        overlay.style.width = "100%";
        overlay.style.height = "100%";
        overlay.style.display = "flex";
        overlay.style.alignItems = "center";
        overlay.style.justifyContent = "center";
        overlay.style.background = "black";
        overlay.style.color = "white";
        overlay.style.zIndex = "10";
        overlay.id = "FetchingOverlay";

        let container = document.createElement("div");
        container.style.position = "relative";
        container.style.width = "100%";
        container.style.height = "100%";

        let iframe = document.createElement('iframe');
        iframe.width = "100%";
        iframe.height = "100%";
        iframe.allow = "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; web-share";
        iframe.referrerPolicy = "strict-origin-when-cross-origin";
        iframe.allowFullscreen = true;
        iframe.src = hrefElement.href + "&FreePremiumVideoSite=1"
        iframe.id = "VideoIframe"
        iframe.style.display = "none";
        container.appendChild(iframe);
        container.appendChild(overlay);
        let fallbackButton = document.createElement("button");
        fallbackButton.textContent = "Click here if nothing happens";
        fallbackButton.style.cssText = `
            position:absolute;
            bottom:20px;
            left:50%;
            transform:translateX(-50%);
            z-index:9999;
            background:#007bff;
            color:white;
            border:none;
            padding:10px 18px;
            border-radius:6px;
            cursor:pointer;
        `;

        fallbackButton.onclick = () => {
            let overlay = document.querySelector("#FetchingOverlay");
            if (overlay) {
                overlay.textContent = "Retrying with user interaction...";
            }
        };

        container.appendChild(fallbackButton);
        hrefElement.parentElement.appendChild(container);
        hrefElement.remove();
        window.addEventListener("message", (e) => {
            let PlayerNotice = document.querySelector("#playerNotice");
            if (PlayerNotice) {
                PlayerNotice.remove();
            }

            if (e.data.startsWith("SwapIframeURL")) {
                let iframe = document.querySelector("#VideoIframe");
                iframe.src = e.data.replace("SwapIframeURL", "");
                setTimeout(() => {
                    iframe.style.removeProperty("display");
                    overlay.remove();
                    fallbackButton.remove();
                }, 500);
            }
            else if (e.data.startsWith("VideoRawURL")) {
                let iframe = document.querySelector("#VideoIframe");
                let videoUrl = e.data.replace("VideoRawURL", "");

                let video = document.createElement("video");

                video.id = "VideoPlayer";
                video.src = videoUrl;
                video.controls = true;
                video.autoplay = true;
                video.playsInline = true;
                video.style.width = "100%";
                video.style.height = "100%";
                iframe.replaceWith(video);
                setTimeout(() => {
                    overlay.remove();
                    fallbackButton.remove();
                }, 500);
            }
        });
    }

    let FreePremium_retry;
    function FreePremium_searchForHref() {
        clearTimeout(FreePremium_retry);

        let a = document.querySelector('a[rel="noreferrer noopener"][href]');
        if (a && a.href) {
            return FreePremium_initIframe(a);
        }

        FreePremium_retry = setTimeout(FreePremium_searchForHref, 1);
    }


    function FreePremium_topInit() {
        let lastHref = location.href;
        if (lastHref.includes("https://sledujserialy.io/episode/") || lastHref.includes("https://ww.sledujfilmy.io/filmy/")) {
            FreePremium_searchForHref();
        }

        new MutationObserver(() => {
            if (location.href !== lastHref) {
                lastHref = location.href;

                if (location.href.includes("https://ww.sledujfilmy.io/filmy/")) {
                    FreePremium_searchForHref();
                }
            }
        }).observe(document, { subtree: true, childList: true });
    }

    let FreePremium_iframeInit_timeout = false;
    function FreePremium_iframeInit(IsVoe) {
        if (IsVoe) {
            let origOpen = XMLHttpRequest.prototype.open;

            XMLHttpRequest.prototype.open = function (method, url, ...args) {
                this._url = url;
                if (typeof url === "string" && url.includes("index-v1")) {
                    window.top.postMessage("VideoRawURL" + url, "*");
                }
                return origOpen.call(this, method, url, ...args);
            };
            setInterval(() => {
                let video = document.querySelector("video");
                if (video) {
                    video.remove();
                }
                let spin = document.querySelector(".spin");
                if (spin) {
                    spin.click();
                }
            }, 100);
        }
        else {
            if (!document.querySelector("iframe")) {
                clearTimeout(FreePremium_iframeInit_timeout);
                FreePremium_iframeInit_timeout = setTimeout(FreePremium_iframeInit, 100);
                return;
            }

            let iframe = document.querySelector('iframe');
            if (iframe && !iframe.src.includes("voe.sx")) {
                window.top.postMessage("SwapIframeURL" + iframe.src, "*");
            }
        }
    }

    if (window.self === window.top && (window.location.href.includes("sledujserialy.io") || window.location.href.includes("sledujfilmy.io"))) {
        FreePremium_topInit();
    }
    else if (window.location.href.includes("johnfullwonder.com")) {
        FreePremium_iframeInit(true);
    }
    else if (!window.location.href.includes("FreePremiumVideoSite=1")) {
        FreePremium_iframeInit(false);
    }
})();